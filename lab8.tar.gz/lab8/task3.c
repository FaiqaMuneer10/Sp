#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{

char arr[]="ereor!";
char buff[1024];


int fd=open("f1.txt",O_RDONLY);

int fd1=open("f2.txt",O_RDONLY|O_WRONLY|O_CREAT|O_TRUNC,0777);

dup2(fd1,2);
dup2(fd1,1);

dup2(fd,0);


if(fd<=0)
{

write(fd1,arr,6);

}
else{


int n;
	for(;;)
	{


		n=read(fd,buff,1024);

			if(n<=0)
			{
		
				close(fd);

				close(fd1);

				return 0;
			}

		write(fd1,buff,n);

	}}



	
					return 0;
}



