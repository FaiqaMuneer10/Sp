#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{

char buff[1024];

int fd=open("/etc/passwd",O_RDONLY);

int fd1=dup(fd);


int n;
	for(;;)
	{


		n=read(fd1,buff,1024);

			if(n<=0)
			{
		
				close(fd);

				close(fd1);

				return 0;
			}

		write(1,buff,n);

	}

				return 0;
}



