#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main(int argc,char *argv[])
{
	if(argc!=2)
	{
	printf("error!");

	}


else if(access(argv[1],W_OK|R_OK)==0 )
{

printf("file ahve reada and write  permision");
}

else if(access(argv[1],R_OK)==0 )
{

printf("file ahve read  permision");
}


else if(access(argv[1],W_OK)==0 )
{

printf("file ahve  write  permision");
}



else if(access(argv[1],X_OK)==0 )
{

printf("file ahve  execute  permision");
}

}
