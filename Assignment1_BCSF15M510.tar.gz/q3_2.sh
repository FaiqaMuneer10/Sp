#!/bin/bash
function is_root(){


if [ $1 = "root" ]
then echo true 
else echo false
fi
}


var=`whoami`
is_root $var


