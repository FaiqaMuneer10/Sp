#!/bin/bash

var=1
cat $1 | while read LINE
do 
if [ `expr $var % 2` -eq 0 ]
then  
               if [ -a Evenfile ]
		then echo $LINE >> Evenfile
		else touch Evenfile
		 echo $LINE >> Evenfile
		fi
else
		if [ -a Oddfile ]
		then echo $LINE >> Oddfile
		else touch Oddfile
		 echo $LINE >> Oddfile
		fi


fi
var=`expr $var + 1 `
done
