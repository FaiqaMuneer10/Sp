#!/bin/bash

function is_lower()
{

echo $1 | tr '[:upper:]' '[:lower:]'

}

if [ $1 = "" ]
then echo "Invalid string .."

else is_lower $1
fi
