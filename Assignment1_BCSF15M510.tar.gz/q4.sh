#!/bin/bash

var=0
> file1
cat $1 | sort | uniq >> file1

cat file1 | while read LINE
do 
if [ $var -eq 0 ]
then echo $LINE > $1
var=`expr $var + 1`
else echo $LINE >> $1

fi
done

