#!/bin/bash

for FILE in *.*
do

if [ -f $FILE   ] 
then

if [  -d ${FILE#*.} ] 
then mv $FILE ${FILE#*.}
else
 mkdir ${FILE#*.}
mv $FILE ${FILE#*.}
fi
fi
done

