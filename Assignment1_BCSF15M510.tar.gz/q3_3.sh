#!/bin/bash

function is_user_exist()
{

cat /etc/passwd | uniq >> file 
var=`grep -i "$1:" file`
if [ $? = 0 ]
then echo "TRUE!"
else echo "FALSE!"
fi

}

is_user_exist $1


