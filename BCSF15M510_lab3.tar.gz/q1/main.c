#include<stdio.h>
#include "mymath.h"
int  main()
{
int x,y;
printf("Enter 1st no :");
scanf("%d",&x);

printf("Enter 2nd no :");
 
scanf("%d",&y);
int Equal=isEqual(x,y);

Swap(x,y);

printf("\n");

if(Equal==-1)
printf("X and y are not equal");


if(Equal==1)
printf("X and y are  equal");


}

