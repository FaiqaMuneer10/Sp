
//is eqaul function
int isPalindrome(char* x , int siz)
{
int f=siz-1;

int flag=1;
	for (int i=0 ;i<siz  ;i++)

	{
		if(x[f]==x[i] )
		{
                  f--;
		flag=1;
		}
		else return -1;


	}

if(flag==1)
{
return 1;
}


}



