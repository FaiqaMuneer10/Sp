int isPalindrome(char *,int );

