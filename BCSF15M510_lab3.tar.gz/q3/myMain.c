#include<stdio.h>
#include"mymath.h"
#include"myStr.h"

int main()
{

Swap (10, 8);

int eq=isEqual(10,8);
	if(eq==1)
	{

	printf("Is equal ..");

	}
	else if(eq==-1)
	{

	printf("Not equal ..");

	}

char arr[5]={"faiqa"};

int fla= isPalindrome(arr,5);
	if(fla==1)
	{

	printf("Is Palindrome..");

	}
	else if(fla==-1)
	{

	printf("Not Palindrome ..");

	}



}

