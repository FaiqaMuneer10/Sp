int isPalindrome(char * ,int );

