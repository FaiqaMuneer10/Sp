#include<stdio.h>
#include "myStr.h"
int  main()
{
char arr[5]={"faiqa"};
int Equal=isPalindrome(arr,5);


printf("\n");

if(Equal==1)
printf(" its a palondrome");


if(Equal==-1)
printf(" its not a palindrom");


}

