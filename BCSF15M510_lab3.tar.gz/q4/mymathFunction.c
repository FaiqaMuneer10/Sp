
//is eqaul function
int isEqual(int x , int y)
{

	if(x==y)
	{
	return 1;
	}

	else 
	{
	return -1;
	}

}

// swap function 
void Swap(int x , int y)
{

x=x+y;
y=x-y;
x=x-y;

	printf("x is %d",x);
printf("\n");
	printf("y is %d",y);

}



