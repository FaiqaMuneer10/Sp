int isEqual(int , int);
void Swap(int , int );
