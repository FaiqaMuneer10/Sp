#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main(int argc,char *argv[])
{

char buff[256];
if(argc!=3)
{

	printf("Argument should be two");
	exit(0);

}

int fd=open(argv[1],O_RDONLY);
if(fd==-1)
{

	printf("Error ! File not opened");
	exit(0);
}

int fd1=read(fd,buff,2000);

int fd2=open(argv[2],O_CREAT|O_WRONLY);

int fd3=write(fd2,buff,fd1);

remove(argv[1]);


}

